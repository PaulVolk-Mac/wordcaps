Safe Zone Overlays 2026 (TikTok, Reels, Shorts)
1. Put the PNG for your platform on the top track of your 9:16 (1080x1920) timeline.
2. Keep text, faces and call-to-actions inside the green box.
3. Hide or delete the overlay track before you export.
checker/index.html: open in any browser, drop a frame or video – nothing is uploaded.
*_safe_zone_*  = shaded blocked areas + green box
*_guide_lines_* = green box only
Captions word by word: https://jaulana.itch.io/wordcaps
