Safe Zone Overlays 2026 (TikTok, Reels, Shorts) - zones checked 19 Nov 2026
1. Put the PNG for your platform on the top track of your 9:16 (1080x1920) timeline.
2. Keep text, faces and call-to-actions inside the green shape.
3. Hide or delete the overlay track before you export.
*_safe_zone_*   = shaded covered areas + green shape
*_guide_lines_* = green shape only
zones.json      = the pixel values with source link and check date per platform
The values are the platforms' published safe zones for ads (TikTok, YouTube) - the cautious choice for
organic posts. Reels: bottom 35% is official (Meta), top and sides are estimates.
Online checker with frame-by-frame video check (nothing is uploaded):
https://paulvolk-mac.github.io/wordcaps/tools/safe-zone-checker/
Captions word by word: https://jaulana.itch.io/wordcaps
